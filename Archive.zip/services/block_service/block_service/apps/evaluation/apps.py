from django.apps import AppConfig

class EvaluationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'block_service.apps.evaluation'
